#include <sys/mman.h>
#include <sys/stat.h>    
#include <fcntl.h>          
#include <string.h>
#include <stdio.h>
#include <unistd.h>


int main()
{
  const int size = 4096;
  const char *message_0 = "Hello ";
  const char *message_1 = "World!";

  const char* nome = "/mem_comp";

  int fd = shm_open(nome, O_CREAT | O_RDWR, 0666); //cria o objeto de memoria compartilhada
  ftruncate(fd, size);
  printf("\nDescritor do objeto de memoria compartilhada: %i",fd);

  char* ptr = (char*)mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0); //faz o mapeamento
  printf("\nEndereco de memoria compartilhada: %p [0...%i]", ptr, size-1);

  sprintf(ptr, "%s", message_0);
  ptr += strlen(message_0);
  sprintf(ptr, "%s", message_1);
  ptr += strlen(message_1);
  sleep(20);
  shm_unlink(nome);
  close(fd);
  return 0;
 }
