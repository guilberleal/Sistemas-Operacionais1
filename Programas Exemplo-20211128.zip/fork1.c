#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

/* Este exemplo visa mostrar a criacao de um processo usando fork(),
 * bem como distiguir a operacao a ser executada pelo processo pai e 
 * pelo filho. Pontos importantes: fork faz dois retornos. Para o
 * processo filho fork retorna 0; para o processo pai fork retorna o
 * PID do filho. */

int main()
{
    int pid = fork(); //cria um processo filho

   if(pid < 0){ //fork retorna -1 em caso de erro
     printf("\nErro na criacao do processo filho!");
     exit(EXIT_FAILURE);
   } 

   if(pid == 0){ //fork retorna 0 para o processo filho
     while(1){
       printf("\nEu sou o processo filho!");
       sleep(1.0);
     }
   }else{ //fork retorna o pid do filho para o processo pai (valor > 0)
     while(1){
       printf("\nEu sou o processo pai!");
       sleep(1.0);
     }
   }
}

