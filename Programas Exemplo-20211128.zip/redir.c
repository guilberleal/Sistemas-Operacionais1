#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>


int main()
{
  int fd = open("tricky.txt", O_CREAT | O_RDWR, 0666);

  dup2(fd, 1);

  printf("\nOla, tudo bem?");
  printf("\nDisciplina SO!!");
  close(fd);
}



