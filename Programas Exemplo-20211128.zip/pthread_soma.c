#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

int soma;
void* worker(void* params);

int main()
{
  const int valor = 100;
  pthread_t tid;
  pthread_attr_t attr;

  pthread_attr_init(&attr);

  pthread_create(&tid, &attr, worker, (void*)&valor);
  pthread_join(tid, NULL);
  printf("\nSoma: %i", soma);
  exit(EXIT_SUCCESS);
}

void* worker(void* params){
  int sup = *((int*)params);
  printf("\nsomando de 0 a %i", sup);
  soma = 0;
  for(int i=0; i <= sup; i++)
    soma += i;

  pthread_exit(0);
}
