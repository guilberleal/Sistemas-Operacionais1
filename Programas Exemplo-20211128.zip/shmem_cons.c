#include <sys/mman.h>
#include <sys/stat.h>   
#include <fcntl.h>         
#include <string.h>
#include <stdio.h>
#include <unistd.h>


int main()
{
  const int size = 4096;

  const char* nome = "/mem_comp"; //nome do objeto de memoria compartilhada

  int fd = shm_open(nome, O_RDWR, 0666); //abre o objeto de memoria compartilhada
  printf("\nDescritor de memoria compartilhada: %i",fd);

  char* ptr = (char*)mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0); //faz o mapeamento
  printf("\nEndereco de memoria compartilhada: %p [0...%i]",ptr, size-1);
  
  printf("%s", ptr);

  shm_unlink(nome);
  return 0;
 }
