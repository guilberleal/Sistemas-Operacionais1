#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

/* Este exemplo visa mostrar como sincronizar o processo pai
 * com o processo filho. O pai vai esperar o termino do processo
 * filho fazendo a chamada de sistema wait(). Essa chamada retorna
 * ao chamador o PID do processo filho que terminou e pode coletar o 
 * status de termino via parametro.  */

int main()
{
    int pid = fork(); //cria um processo filho

   if(pid < 0){ //fork retorna -1 em caso de erro
     printf("\nErro na criacao do processo filho!");
     exit(EXIT_FAILURE);
   } 

   if(pid == 0){ //fork retorna 0 para o processo filho
     for(int i=0; i<30; i++){
       printf("\nEu sou o processo filho! %i", getpid());
       sleep(1.0);
     }
     //filho termina
     exit(EXIT_FAILURE);

   }else{ //fork retorna o pid do filho para o processo pai (valor > 0)
      int status;
      int pid_filho = wait(&status);
      printf("\nEu sou o processo pai. Filho %i acaba de terminar com status %i!",pid_filho, status); 
   }
}

