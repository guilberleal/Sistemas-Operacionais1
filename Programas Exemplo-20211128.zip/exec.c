#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
   pid_t pid =  fork();
   if(pid == -1){
     perror("\nFalha na criacao do processo filho!");
     exit(EXIT_FAILURE);
   }

   if(pid == 0){//processo filho
     printf("\nFilho vai executar um novo programa!");
     execlp("/usr/bin/ls", "ls", NULL);
     printf("\nFilho terminou de rodar ls!");
   }else{//processo pai
    int proc_filho = wait(NULL);
    printf("\nProcesso filho terminou!");
   }

}
