#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

/* Este exemplo visa analisar o numero de processos criados
 * por uma sequencia de chamadas fork. Em geral, temos 2^n
 * processos criados, onde n eh o numero de chamadas fork() */

int main()
{
    fork();
    fork();
    fork();
    
    while(1)
    {
       printf("\nEscreveu na saida padrao!");
       sleep(1.0);
    }
}

