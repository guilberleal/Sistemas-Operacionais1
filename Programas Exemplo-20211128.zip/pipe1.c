#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

/* Este exemplo visa mostrar a comunicao entre dois processos
 * (pai e filho) usando um pipe oridinario. */

int main()
{
   int pid; //para o retorno de fork
   int fd[2]; //descritores para o pipe
   char buff[256]; //beffer para leitura de dados
    
   if(pipe(fd) < 0){
     printf("\nErro na criacao do pipe!");
     exit(EXIT_FAILURE);
   }
	
   pid = fork(); //cria um processo filho
   if(pid < 0){ //fork retorna -1 em caso de erro
     printf("\nErro na criacao do processo filho!");
     exit(EXIT_FAILURE);
   } 


   if(pid == 0){ //fork retorna 0 para o processo filho
     close(fd[1]); //fecha descritor de escrita
     read(fd[0],buff,256);
     printf("\nFilho leu do pipe: %s",buff);
     exit(EXIT_SUCCESS);
   }else{ //fork retorna o pid do filho para o processo pai (valor > 0)
     close(fd[0]);
     write(fd[1],"Ola! tudo bem?", 15);
     close(fd[1]);
     wait(NULL);
     printf("\nProcesso filho terminou...");
   }
}

