#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

/* Este exemplo visa mostrar a criacao de um processo orfao. 
 * Processos orfaos sao aqueles que o pai morre primeiro que
 * filho. Esses processos sao adotados por um processo do sistema*/

int main()
{
    int pid = fork(); //cria um processo filho

   if(pid < 0){ //fork retorna -1 em caso de erro
     printf("\nErro na criacao do processo filho!");
     exit(EXIT_FAILURE);
   } 

   if(pid == 0){ //fork retorna 0 para o processo filho
     while(1){
       printf("\nEu sou o processo filho!");
       sleep(1.0);
     }
   }else{ //fork retorna o pid do filho para o processo pai (valor > 0)
     for(int i=0; i<30; i++){
       printf("\nEu sou o processo pai!");
       sleep(1.0);
     }
   }
}

